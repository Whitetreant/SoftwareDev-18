Make sure these boxes are checked before submitting your issue:

[] Check that your version of Python is 3.4+
[] Check that you are on the newest version of Pyrebase
[] Check that Email/password provider is enabled in your Firebase dashboard under Auth -> Sign In Method.

Please don't be discouraged if you do not get a response to your issue quickly,
I maintain Pyrebase for fun and don't always have as much free time as I'd like.

Thank you for helping make Pyrebase better!